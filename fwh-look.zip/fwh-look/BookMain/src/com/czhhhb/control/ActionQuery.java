package com.czhhhb.control;

import com.czhhhb.db.Dbobject;
import com.czhhhb.model.Book;

import javax.swing.*;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

public class ActionQuery implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {

        //实现图书查询功能，监听实现gui 并且调用数据库操作

    }
}

